package com.mt.insurancepolicies.exceptions;

public class InvalidCompanyNameException extends RuntimeException{

	public InvalidCompanyNameException(String msg) {
		super(msg);
	}
	
}
