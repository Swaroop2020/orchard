package com.mt.insurancepolicies.exceptions;

public class InvalidPolicyException extends RuntimeException{

	public InvalidPolicyException(String message) {
		super(message);
	}
	
}
