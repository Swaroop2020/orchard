package com.mt.insurancepolicies.exceptions;

public class ControllerException extends RuntimeException{

	public ControllerException(String msg) {
		super(msg);
	}
	
}
