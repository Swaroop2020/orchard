package com.mt.insurancepolicies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsurancePolicyManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsurancePolicyManagerApplication.class, args);
	}

}
