package com.mt.insurancepolicies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsurancePolicyManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
